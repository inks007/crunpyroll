class CrunpyrollException(Exception):
    pass

class ClientNotAuthorized(CrunpyrollException):
    pass