from .obj import Object

class Content(Object):
    pass